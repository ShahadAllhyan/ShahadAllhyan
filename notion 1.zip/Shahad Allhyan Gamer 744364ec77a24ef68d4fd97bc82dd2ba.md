# Shahad Allhyan | Gamer

Gaming |call of duty

![output-onlinegiftools.gif](Shahad%20Allhyan%20Gamer%20744364ec77a24ef68d4fd97bc82dd2ba/output-onlinegiftools.gif)

- **Introduction**
    - I intend to refine and develop my skills in the scientific and practical fields and help raise the
    work organization to levels of excellence and to be part of the organization and support it
    by applying the academic skills and knowledge I possess ,  My passion has always been education and knowledge, through which I can enlighten others .
    
- **Skills**
    - java ,python and C++
    - microsoft office programs
    - system anlysis and desighn
- **Languages**
    - Arabic
    - English
- **Education**
    - Prince Sattam Bin Abdulaziz University
    - Bechalor Of Computer Scince
- **Courses**
    - Protecting systems from hacking
    - Cyber attack and penetration techniques
    - Website programming using html5, css3 and JavaScript
    - The Internet of Things and promising opportunities
    - Problem solving skills in the work environment
    - Successful communication skills at work
    - Basics of quality and safety standards
    - Cyber security
    - digital analysis
    - artificial intelligence
    - Search engine optimization
    - Be a professional problem solver
    - time management
    - management basics

## 💻 Projects

[Untitled Database](Shahad%20Allhyan%20Gamer%20744364ec77a24ef68d4fd97bc82dd2ba/Untitled%20Database%207eb6f0fc4adf4e23b29dedd4ee5d672c.csv)